# Hamming SDK

SDK for interacting with the Hamming AI platform.
